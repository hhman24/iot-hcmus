
#pragma once

#ifndef ESP_MAIL_VERSION

#define ESP_MAIL_VERSION "2.5.2"

#endif